export default (categories = [], action) =>  {
  let newState = [...categories]
  switch(action.type){
    case "SET_MENU_CATEGORIES":
      return  action.payload.categories
    
    default:
      return newState
  }
}
