export default (menu = [], action) =>  {
  let newState = [...menu]
  switch(action.type){
    case "SET_MENU_ITEMS":
      const { menuItems } = action.payload
      newState = menuItems
      break;
    
    default:
  }
  return newState
}