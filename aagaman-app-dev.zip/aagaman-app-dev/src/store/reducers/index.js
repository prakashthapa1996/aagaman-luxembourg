import CartMenuReducer from "./cartMenuReducer"
import MenuCategoryReducer from "./menuCategoryReducer"
import MenuItemsReducer from "./menuItemsReducer"
import TermsConditionReducer from "./termsConditionsReducer"

import { combineReducers } from "redux"

export default combineReducers({
  cartMenu: CartMenuReducer,
  categories: MenuCategoryReducer,
  menu: MenuItemsReducer,
  termsConditionIsOpen: TermsConditionReducer,
})