export default (termsConditionIsOpen = false, action) =>  {
  switch(action.type){
    case "OPEN_TERMS_CONDITIONS":
      return true;

    case "CLOSE_TERMS_CONDITIONS":
      return false 

      default:
      return termsConditionIsOpen
  }
}