export default (cartMenu = [] , action) => {

  switch(action.type) {
    case "ADD_TO_CART":
      const itemToAdd = cartMenu.find(item => item.id === action.payload.id)
      itemToAdd || cartMenu.push({
        id: action.payload.id,
        quantity : 1,
        spices: 0
      })
      break

    case "REMOVE_FROM_CART":
      const itemToRemove = cartMenu.find(item => item.id === action.payload.id)
      const index = cartMenu.indexOf(itemToRemove)
      index >= 0 && cartMenu.splice(index, 1)
      break      

    case "SET_ITEM_QUANTITY":
      const currentItem = cartMenu.find(item => item.id === action.payload.id)
      currentItem && (currentItem.quantity = action.payload.quantity)
      break

    case "SET_ITEM_SPICE":
      const current = cartMenu.find(item => item.id === action.payload.id)
      current && (current.spices = action.payload.spices)
      break

    case "CLEAR_CART":
      cartMenu = []
      break

    default:
  }
  return ( [...cartMenu])
}