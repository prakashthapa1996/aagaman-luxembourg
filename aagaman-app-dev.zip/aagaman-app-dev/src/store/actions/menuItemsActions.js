export const setMenuItems = (menuItems) => {
  return {
    type: "SET_MENU_ITEMS",
    payload: { menuItems }
  }
}