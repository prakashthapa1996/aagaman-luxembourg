export function addToCart(itemId) {
  return {
    type: "ADD_TO_CART",
    payload: {
      id: itemId
    }
  }
}

export function setSpiceValue(itemId, value) {
  return {
    type: "SET_ITEM_SPICE",
    payload: {
      id: itemId,
      spices: value
    }
  }
}

export function removeFromCart(itemId) {
  return {
    type: "REMOVE_FROM_CART",
    payload: {
      id: itemId
    }
  }
}

export function setItemQuantity(itemId, quantity) {
  return {
    type: "SET_ITEM_QUANTITY",
    payload: {
      id: itemId,
      quantity: quantity
    }
  }
}

export function clearCart() {
  return {
    type: "CLEAR_CART"
  }
}