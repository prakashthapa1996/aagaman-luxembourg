export const openTermsConditions = () => {
  return {
    type: "OPEN_TERMS_CONDITIONS"
  }
}

export const closeTermsConditions = () => {
  return {
    type: "CLOSE_TERMS_CONDITIONS"
  }
}