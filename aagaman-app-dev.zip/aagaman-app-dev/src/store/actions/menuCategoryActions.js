export const setMenuCategories = (categories) => {
  return {
    type: "SET_MENU_CATEGORIES",
    payload: { categories }
  }
}