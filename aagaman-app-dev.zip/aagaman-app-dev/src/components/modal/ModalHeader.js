import React from 'react'
import PropTypes from 'prop-types'

const ModalHeader = ({title, dismiss}) => {
  return (
    <div className="modal-header">
      <h5 className="modal-title">{title}</h5>
      <button type="button" className="close" data-dismiss="modal" aria-label="Close" onClick={dismiss}>
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  )
}

ModalHeader.propTypes = {
  title: PropTypes.string.isRequired,
  dismiss: PropTypes.func.isRequired
}

export default ModalHeader