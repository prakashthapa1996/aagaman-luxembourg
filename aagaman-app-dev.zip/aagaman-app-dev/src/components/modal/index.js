import React from 'react'
import PropTypes from 'prop-types'

const Modal = ({isOpen, dismissable, children}) => {
  const modalStyle = isOpen? {display: "block"}: {display: "none"}
  return (
    <div className="modal" tabIndex="-1" role="dialog" style={modalStyle}>
      <div className="modal-dialog font-sm" role="document">
        <div className="modal-content">
            {children}
        </div>
      </div>
    </div>
  )
}

Modal.propType = {
  children: PropTypes.element,
  dismissable: PropTypes.bool,
  isOpen: PropTypes.bool.isRequired
}

Modal.defaultProps = {
  dismissable: false
}

export default Modal