import { Link } from "gatsby"
import PropTypes from "prop-types"
import React from "react"
import aagamanLogo from "../images/aagaman-logo.png"

const Header = () => {
  const [collapsed, toggleHeader] = React.useState(true);
  const togglerClassname = collapsed? "navbar-toggler": "navbar-toggler collapsed";
  const navContentClassName = collapsed ? "collapse navbar-collapse": "collapse navbar-collapse show";

  return (
    <nav className="navbar navbar-expand-lg navbar-light sb-navbar">
      <div className="container col-md-10">
        <Link to="/" className="navbar-brand">
          <img className="nav-logo" src={aagamanLogo} alt="aagaman-logo"/>
        </Link> 

        <button className={togglerClassname} type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded={!collapsed} aria-label="Toggle navigation"
        onClick={() => toggleHeader(!collapsed)}>
          <i className="fas fa-bars"></i>
        </button>
        
        <div className={navContentClassName} id="navbarSupportedContent">
          <ul className="navbar-nav ml-auto pt-3 pt-lg-0">
            <li className="nav-item"><Link to="/">Home</Link></li>
            <li className="nav-item"><Link to="/menu">Menu</Link></li>
            <li className="nav-item"><Link to="/gallery">Gallery</Link></li>
            <li className="nav-item"><Link to="/reserve-table">Reserve a Table</Link></li>
            <li className="nav-item"><Link to="/contact-us">Contact Us</Link></li>
          </ul>
        </div>        
      </div>
    </nav>
)};

Header.propTypes = {
  siteTitle: PropTypes.string,
}

Header.defaultProps = {
  siteTitle: `Welcome to Aagaman`,
}

export default Header
