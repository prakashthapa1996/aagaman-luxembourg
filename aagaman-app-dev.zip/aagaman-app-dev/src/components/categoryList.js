import React from 'react'

const CategoryList = ({categories}) => {
  return (
    <ul style={{position: "sticky", top: 0}}>
      <h6 style={{height: 54, paddingTop: 16}}>CATEGORIES</h6>
      {
        categories.map(({id, name}) => (
          <li key={id}>
            <a className="menu-category-item" href={`#menu-${id}`}>{name}</a>
          </li>
          )
        )
      }
    </ul>      

  )
}

export default CategoryList