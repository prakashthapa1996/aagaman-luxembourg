import React from 'react'
import {useSelector, useDispatch} from 'react-redux'
import { clearCart, setSpiceValue} from "../../store/actions/cartMenuActions"
import Modal from '../modal'
import ModalHeader from '../modal/ModalHeader'
import ModalBody from '../modal/ModalBody'
import ModalFooter from '../modal/ModalFooter'
import OrderForm from './orderForm'
import { sendMail } from '../../api/mail'
import renderMail from './renderMail'

const confirmOrder = ({isOpen, toggleModal}) => {
  let inputRefs = []
  let paymentRefs = []
  let deliveryRefs = []

  const dispatch = useDispatch()
  const categories = useSelector(store => store.categories)
  const menu = useSelector(store => store.menu)
  const cartMenu = useSelector(store => store.cartMenu)

  const createInputRef = () => {
    const ref = React.createRef()
    inputRefs.push(ref)
    return ref
  }

  const createPaymentRef = () => {
    const ref = React.createRef()
    paymentRefs.push(ref)
    return ref
  }

  const createDeliveryRef = () => {
    const ref = React.createRef()
    deliveryRefs.push(ref)
    return ref
  }
  
  const getFormData = () => {
    const formData = inputRefs.reduce((acc, ref) => {
      acc[ref.current.name]= ref.current.value
      return acc
    }, {})

    formData["Payment Method"] = getPaymentOption()
    formData["Delivery Method"] = getDeliveryOption()

    return formData
  }

  const getPaymentOption = () => {
    return paymentRefs
      .find(one => one.current.checked)
      .current.value
  }

  const getDeliveryOption = () => {
    return deliveryRefs
      .find(one => one.current.checked)
      .current.value
  }

  const getRowContents = (id) => {
    const menuElement = menu.find(el => el.id === id)
    const cartMenuElement = cartMenu.find(el => el.id === id)
    const categoryName = categories.find(el => menuElement.categoryId === el.id).name
    return {
      id,
      name: menuElement.name,
      category: categoryName,
      price: menuElement.price,
      quantity: cartMenuElement.quantity,
      spices: cartMenuElement.spices,
      totalCost: ( menuElement.price * cartMenuElement.quantity) 
    }
  }

  const mappedData = cartMenu.map( item => getRowContents(item.id))
  const getMappedTable = ({id, name, category, price, quantity, spices, totalCost}) => {
    const getButtonStyle = (index) => {
      return (index > spices)? { color: 'var(--secondary)' } : { color: 'var(--primary-color)' }
    }

    const setSpice = (value) => {
      dispatch(setSpiceValue(id, value))
    }

    const renderSpices = () => {
      return (
        <div className="d-flex flex-row">
          {
            [0, 1, 2].map(i => {
            return <i key={i} className="fas fa-pepper-hot mx-1 confirm-order__spices" onClick={() => setSpice(i)} style={getButtonStyle(i)}></i>
          })}
        </div>
      )
    }
    return (
      <tr key={id}>
        <td data-name="Id">{id}</td>
        <td data-name="Name">{name}</td>
        <td data-name="Category">{category}</td>
        <td data-name="Price">{price}</td>
        <td data-name="Quantity">{quantity}</td>
        <td data-name="Spices">{renderSpices()}</td>
        <td data-name="Cost">{totalCost}</td>
      </tr>
    )
  }

  const calculateTotal = (menuItems) => {
    return menuItems.reduce((acc, current) => (acc + current.totalCost), 0)
  }

  const onConfirm = (e) => {
    e.preventDefault()
    console.group(renderMail(mappedData, getFormData()))
    sendMail({
      to: "contact@aagaman.lu",
      subject: `Online Order from ${getFormData()['Full Name']}`,
      html: renderMail(mappedData, getFormData())})
      .then(() => {
        dispatch(clearCart())
        toggleModal(false)
        // navigate('/')
      })
  }

  const onCancel = () => {
    toggleModal(false)
  }

  return (
    isOpen &&
    <Modal isOpen={isOpen} >
      <form className="modal-content"onSubmit={onConfirm}>
        <ModalHeader title="Confirm Order" dismiss={onCancel} />
          <ModalBody>
            <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Spices</th>
                <th>Cost</th>
              </tr>
            </thead>

            <tbody>
              {mappedData.map( item => getMappedTable(item))}

              <tr>
                <td/>
                <td><strong>Total</strong></td>
                <td/>
                <td/>
                <td/>
                <td/>
                <td><strong>{calculateTotal(mappedData).toFixed(2)}</strong></td>            
              </tr>
            </tbody>
          </table>

          <div style={{fontSize: "0.8rem", fontWeight: 400, marginLeft: "1.2rem"}}>
            <strong>Note:</strong> All prices are exclusive of delivery charges.  
            <div className='mt-2'>
              <i className="fas fa-pepper-hot mx-1 confirm-order__spices" style={{color: "var(--primary-color)"}}></i>
              <i className="fas fa-pepper-hot mx-1 confirm-order__spices" style={{color: "var(--secondary)"}}></i>
              <i className="fas fa-pepper-hot mx-1 confirm-order__spices" style={{color: "var(--secondary)"}}></i>
              : MILD
            </div>

            <div className='mt-2'>
              <i className="fas fa-pepper-hot mx-1 confirm-order__spices" style={{color: "var(--primary-color)"}}></i>
              <i className="fas fa-pepper-hot mx-1 confirm-order__spices" style={{color: "var(--primary-color)"}}></i>
              <i className="fas fa-pepper-hot mx-1 confirm-order__spices" style={{color: "var(--secondary)"}}></i>
              : SPICY
            </div>

            <div className='mt-2'>
              <i className="fas fa-pepper-hot mx-1 confirm-order__spices" style={{color: "var(--primary-color)"}}></i>
              <i className="fas fa-pepper-hot mx-1 confirm-order__spices" style={{color: "var(--primary-color)"}}></i>
              <i className="fas fa-pepper-hot mx-1 confirm-order__spices" style={{color: "var(--primary-color)"}}></i>
              : VERY SPICY
            </div>
          </div>
          <OrderForm  createInputRef={createInputRef} createPaymentRef={createPaymentRef} createDeliveryRef={createDeliveryRef} />
        </ModalBody>

        <ModalFooter>
          <button type="button" className="btn btn-secondary" data-dismiss="modal" onClick={onCancel}> Cancel </button>
          <button type="submit" className="btn btn-primary"> Confirm </button>
        </ModalFooter>
      </form>
    </Modal>
  )
}

export default confirmOrder