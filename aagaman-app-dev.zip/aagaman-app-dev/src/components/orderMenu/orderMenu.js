import React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'gatsby';
import { useDispatch } from 'react-redux'; 
import OrderMenuItem from './orderMenuItem';
import { openTermsConditions } from '../../store/actions/termsConditions';

const OrderMenu = ({ toggleView, toggleConfirmModal }) => {
  const dispatch = useDispatch()
  const cartMenu = useSelector(store => store.cartMenu)
  const menu = useSelector(store => store.menu)
  const categories = useSelector(store => store.categories)

  let total = 0
  for(let cartItem of cartMenu){
    const menuItem = menu.find(el => el.id === cartItem.id)
    total += cartItem.quantity * menuItem.price
  }

  const openOrderModal = () => {
    toggleConfirmModal(true) 
    toggleView(false)
  }

  const openTermsModal = (e) => {
    e.preventDefault()
    dispatch(openTermsConditions())
  }

  return (
    <div className="menu-sidebar-layout" onClick={toggleView}>
      <section className="order-menu-column" style={{height: "100%", float:"right", padding: 0}} onClick={e => e.stopPropagation()}>
        <div className="order-menu-header">
          <div className="text-white text-center" style={{ flexGrow: 1, alignSelf: "center", fontWeight: 600 }}> Your Order Menu</div>
          <button className="close-button" onClick={toggleView}><i className="fas fa-times text-white no-background"></i></button>
        </div>
 
        { (cartMenu.length < 1) ?
          <div className="mx-3 text-center my-auto">
            <div>
              No order has been placed yet. Please navigate to menu and place your Order
            </div>
            <Link to="/menu" className="text-white">
              <button className="btn btn-primary m-3" onClick={toggleView}> Go To Menu </button>
            </Link>
            <br/>
            <a href="#" className="link-terms-conditions font-sm" onClick={openTermsModal}> Open Terms & Conditions </a>
          </div>:
          <React.Fragment>
          <ul className="py-3 px-3 flex-grow" style={{overflowY: 'scroll'}} >
            {
              cartMenu.map( item => {
                const menuItem = menu.find(el => el.id === item.id)
                const category = categories.find(el => el.id === menuItem.categoryId)
                return <OrderMenuItem cartItem={item} menuItem={menuItem} category={category} key={item.id} /> } ) 
            }
          </ul>
          <div className='order-menu-bottom-section flex-row nowrap'>
            <div className="px-3 py-auto">
              <label className="font-sm"> Total </label>  € {total.toFixed(2)}
            </div>

            <button className="btn-create-order" onClick={openOrderModal}>Create Order</button>
          </div>
          </React.Fragment>
        }
      </section>
    </div>
  )
}

export default OrderMenu