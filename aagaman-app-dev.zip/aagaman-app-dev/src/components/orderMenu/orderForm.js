import React from 'react'

const OrderForm = ({createInputRef, createDeliveryRef, createPaymentRef}) => {

  return (
    <div className="py-3 col-md-12 mx-auto contact-form">
      
        <h5 className="mt-4">Your Details</h5>
        <div className="row">
          <div className="col-md-6">
            <div className="form-group">
              <input ref={createInputRef()} required type="text" name="Full Name" className="form-control" placeholder="Full Name *" autoComplete="off" />
            </div>
            <div className="form-group">
              <input ref={createInputRef()} required type="text" name="Address" className="form-control" placeholder="Address *" autoComplete="off" />
            </div>
            <div className="form-group">
              <input ref={createInputRef()} required type="text" name="House Number" className="form-control" placeholder="House Number *" autoComplete="off" />
            </div>
            <div className="form-group">
              <input ref={createInputRef()} required type="text" name="Postal Code" className="form-control" placeholder="Postal Code *" autoComplete="off" />
            </div>
            <div className="form-group">
              <input ref={createInputRef()} required type="text" name="City" className="form-control" placeholder="City *" autoComplete="off" />
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <input ref={createInputRef()} required type="email" name="Email" className="form-control" placeholder="Your Email *" autoComplete="off" />
            </div>
            <div className="form-group">
              <input ref={createInputRef()} required type="tel" name="Phone" className="form-control" placeholder="Your Phone Number *"  autoComplete="off" />
            </div>
            <div className="form-group">
              <textarea ref={createInputRef()} type="text" name="Messaage" className="form-control" placeholder="Special Request"  autoComplete="off" style={{width:"100%", height:"150px"}}></textarea>
            </div>
          </div>
        </div>

        <div className="row"> 
          <div className="col-md-6">
            <h5 className="mt-4">Payment Options</h5>
            <div className="radio">
              <label><input ref={createPaymentRef()} type="radio" name="payment" value="Cash On Delivery" defaultChecked/> Cash On Delivery </label>
            </div>
            <div className="radio">
              <label><input ref={createPaymentRef()} type="radio" name="payment" value="Credit Card"/> Credit Card </label>
            </div>
            <div className="radio">
              <label><input ref={createPaymentRef()} type="radio" name="payment" value="Sodexo Ticket"/> Sodexo Ticket </label>
            </div>
          </div>

          <div className="col-md-6">
            <h5 className="mt-4">Delivery Options</h5>
            <div className="radio">
              <label><input ref={createDeliveryRef()} type="radio" name="delivery" value="Home Delivery" defaultChecked/> Home Delivery </label>
            </div>
            <div className="radio">
              <label><input ref={createDeliveryRef()} type="radio" name="delivery" value="Self Pickup"/> Self Pickup </label>
            </div>
            <div className="radio">
              <label><input ref={createDeliveryRef()} type="radio" name="delivery" value="Office Lunch"/> Office Lunch </label>
            </div>
          </div>
        </div>

    </div>
  )
}

export default OrderForm