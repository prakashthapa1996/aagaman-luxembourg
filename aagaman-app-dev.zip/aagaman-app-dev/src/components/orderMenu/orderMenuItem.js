import React from 'react'
import { useDispatch } from 'react-redux'
import {removeFromCart, setItemQuantity} from '../../store/actions/cartMenuActions'

const OrderMenuItem = ({cartItem, menuItem, category}) => {

  const dispatch = useDispatch()
  const { quantity } = cartItem

  const updateItemQuantity =  q => e => {
    (q >= 1) && dispatch(setItemQuantity(cartItem.id, q));
  }

  const removeCurrent = () => {
    dispatch(removeFromCart(cartItem.id))
  }

  return (
    <div className="flex-nowrap flex-row order-menu-item">
      
      <div className="flex-grow">
        <div className="menu-item-title"> {menuItem.name} </div>
        <div className="font-sm"> {category.name} </div>
        <div className="menu-item-order-count">
          <button onClick={updateItemQuantity(quantity-1)}>
            <i className="fas fa-angle-down"></i>
          </button>
          <span>{quantity}</span>
          <button onClick={updateItemQuantity(quantity+1)}>
            <i className="fas fa-angle-up"></i>
          </button>
        </div>
      </div>
      
      <div className="flex-column" style={{display: 'flex', justifyContent: "space-between", alignItems: "flex-end"}}>        
        <button className="order-menu__remove mt-2 font-sm" onClick={removeCurrent}>
          <i className="far fa-trash-alt mx-1"></i>
        </button>
        <div className="menu-item-price"> {menuItem.price} </div>
      </div>        
    </div>
    );
}

export default OrderMenuItem