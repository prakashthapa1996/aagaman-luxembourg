export default (orderMenu, formData) => {
  const renderFormData = () => {
    const keys = Object.keys(formData)
    const renderRows = keys.map(key => `<div><strong>${key} : </strong>${formData[key] || '<i>Unavailable</i>'}</div><br/>`)
                          .reduce((final, current) => final+current, "")
    return `
      <h3>New Order from ${formData['Full Name']}</h3>
      ${renderRows}
    `
  }

  const thead = `
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>Spices</th>
        <th>Total Cost</th>
      </tr>
    </thead>`

  const spiceValue = (spices) => {
    switch(spices){
      case 0:
        return 'MILD'
      case 1:
        return 'SPICY'
      case 2:
        return 'VERY SPICY'
      default:
      return ''
    }
  }

  const renderRow = ({id, name, price, quantity, spices}) => `
    <tr>
      <td>${id}</td>
      <td>${name}</td>
      <td>${price}</td>
      <td>${quantity}</td>
      <td>${spiceValue(spices)}</td>
      <td>${price*quantity}</td>
    </tr>`

    return `
      ${renderFormData()}
      <table border='1'>
        ${thead}
        <tbody>
          ${orderMenu.map(renderRow).reduce((final, current) => final+current, "")}
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td>${orderMenu.reduce((total, {price,quantity}) => total+price*quantity, 0).toFixed(2)}</td>
          </tr>
        </tbody>
      </table>`
}