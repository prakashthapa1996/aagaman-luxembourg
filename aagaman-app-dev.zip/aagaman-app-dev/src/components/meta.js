import React from 'react'
import eggsImage from '../images/meta/1-eggs.png'
import fishImage from '../images/meta/2-fish.png'
import milkImage from '../images/meta/3-milk.png'
import nutsImage from '../images/meta/4-nuts.png'
import gluteImage from '../images/meta/5-glute.png'

const MetaTags = ({metaIndices}) => {

  const mapIndex = (index) => {
    switch(index){
      case "1":
        return {image: eggsImage, tag: "Contains Oeuf/Eggs"}

      case "2":
        return {image: fishImage , tag: "Contains Poisson/Fish"}

      case "3":
        return {image: milkImage, tag: "Contains Lait/Milk"}

      case "4":
        return {image: nutsImage, tag: "Contains Noix/Nuts"}
      
      case "5":
        return {image: gluteImage, tag: "Contains Gluten/Glute"}
      
      default:
        return {}
    }
  }

  return (
    metaIndices && metaIndices.map(index => (
      <span key={index} className="menu-item__meta-tag" >
        <img className="meta-image" src={mapIndex(index).image} alt={mapIndex(index).tag} />
        <span className="tooltip"> {mapIndex(index).tag}</span>
      </span>))
  )
}

export default MetaTags