import React from 'react';
import CardGroup from './cards';

export default ({topPicks=[]}) => {
  function arraySlice (list, count) {
    let result = []
    let a = list.slice(0)
    while (a[0]) {
      result.push(a.splice(0, count))
    }
    return result
  }
  
  return (
    <div id="carouselIndicators" className="carousel slide" data-ride="carousel">
      
      <div className="carousel-inner" role="listbox">
        {arraySlice(topPicks,4).map( items => (
          <div className="carousel-item"> <CardGroup items={items} /> </div>
        ))}
      </div>
      
      
      <a className="carousel-control-prev" href="#carouselIndicators" role="button" data-slide="prev" >
        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
        <span className="sr-only">Previous</span>
      </a>
      <a className="carousel-control-next" href="#carouselIndicators" role="button" data-slide="next" >
        <span className="carousel-control-next-icon" aria-hidden="true"></span>
        <span className="sr-only">Next</span>
      </a>
    </div>
  );
}