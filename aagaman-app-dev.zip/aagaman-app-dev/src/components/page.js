import React from "react"
import { useSelector, useDispatch } from "react-redux"
import { setMenuCategories } from "../store/actions/menuCategoryActions"
import { setMenuItems } from "../store/actions/menuItemsActions"
import { requestMenu } from "../api/menu"
import { requestCategories } from "../api/categories"

const Page = ({ children }) => {
  const dispatch = useDispatch()
  const categories = useSelector(store => store.categories)
  const menu = useSelector(store => store.menu)

  React.useEffect(() => {
    if (!categories.length || !menu.length) {
      Promise.all([requestCategories(), requestMenu()]).then(values => {
        dispatch(setMenuCategories(values[0]))
        dispatch(setMenuItems(values[1]))
      })
    }
  })
  return <React.Fragment>{children}</React.Fragment>
}

export default Page
