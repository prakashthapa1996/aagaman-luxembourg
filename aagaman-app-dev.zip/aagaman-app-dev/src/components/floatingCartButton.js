import React from 'react'
import { useSelector } from 'react-redux';

const FloatingCartButton = ({ toggleSidebar }) => {
  
  const cartMenu = useSelector((state) => state.cartMenu )
  const {length} = cartMenu

  return (
    <button className="floating-menu-button" onClick={toggleSidebar}>
      <i className="fas fa-shopping-cart"></i>
      
      { length !== 0 && 
        <label className="order-number-label font-sm text-center"> { length } </label>
      }
    </button>
  )
}

export default FloatingCartButton