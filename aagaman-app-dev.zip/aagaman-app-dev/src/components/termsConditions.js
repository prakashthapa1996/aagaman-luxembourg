import React from 'react';
import { useDispatch } from 'react-redux';
import Modal from './modal';
import ModalHeader from './modal/ModalHeader';
import ModalBody from './modal/ModalBody';
import { closeTermsConditions } from '../store/actions/termsConditions'

const TermsConditions = ({isOpen, onDismiss}) => {
  const dispatch = useDispatch()

  return (
    <Modal isOpen={isOpen} dismissable={true}>
      <ModalHeader title="Terms & Conditions" dismiss={() => dispatch(closeTermsConditions())}/>
      <ModalBody>

        <li className='li-bulleted'>We are open from 12:00 - 14:00 Hours and 18:00 - 23:00 Hours.</li>
        <li className='li-bulleted'>During the opening hours, your Take- way (Self Collect) orders are welcome!</li>
        <li className='li-bulleted'>Delivery service for Online Order is available 6 days a week at your doorsteps.</li>
        <li className='li-bulleted'>Home and Office delivery services are available from 12:30 - 14:00 hours and 18:30 - 22:30 hours, Tuesday to Sunday.</li>
        <li className='li-bulleted'>Kindly order before 1 hour to be delivered at time to your doorsteps.</li>
        <li className='li-bulleted'>Order above 25 Euros ; delivery will be entertained within 8KM from the restaurant only.</li>
        <li className='li-bulleted'>Order above 30 Euros ; delivery will be entertained within 10KM from the restaurant only.</li>
        <li className='li-bulleted'>Order above 100 Euros ; delivery will be entertained within 10 - 12KM from the restaurant in exceptional cases only.</li>
        <li className='li-bulleted'>In case you want to pay your online order by Credit card at delivery, please kindly mention in the order note while placing the order.</li>
        <li className='li-bulleted'>Payment by VISA, Mastercard, Maestro, V Pay, Cash and Sodexo-ticket resto are welcome.</li>
        <li className='li-bulleted'>We do not accept American Express.</li>
      </ModalBody>

    </Modal>
  )
}

export default TermsConditions