import React from 'react';
import { useDispatch } from 'react-redux'
import { addToCart } from '../store/actions/cartMenuActions'
import MetaTags from './meta';

export default ({data, isAddedToCart}) => {

  const dispatch = useDispatch()
  const dispatchAddToCart = id => e => {
    e.stopPropagation()
    dispatch(addToCart(id))
  }

  return (
    <div>
      <div className="nowrap mb-2">
        <div style={{flexGrow: 1}}>
          <div className="menu-item-title">{data.name}</div> 
          {data.meta && <MetaTags metaIndices={data.meta}/>}
          <div className="menu-item-price">{data.price}</div> 
        </div>
        <div>
          <button className="font-sm btn btn-primary" onClick={ dispatchAddToCart(data.id) } disabled={isAddedToCart}>
            Add to Cart
          </button>
        </div>
      </div>
      <div className='menu-item-description'>
      {
        data.description && (
          <React.Fragment>
            {data.description.map(item => (
              <div className="font-sm font-light" key={item}> <i className="fas fa-hand-point-right red"></i> {item} </div>
            ))}
          </React.Fragment>
        )
      }
      </div>
    </div>
  )
}