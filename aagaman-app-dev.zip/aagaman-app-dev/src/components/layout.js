/**
 * Layout component that queries for data
 * with Gatsby's StaticQuery component
 *
 * See: https://www.gatsbyjs.org/docs/static-query/
 */

import React from "react"
import PropTypes from "prop-types"
import { StaticQuery, graphql } from "gatsby"
import { useSelector } from "react-redux"
import Page from "./page"
import Header from "./header"
import Footer from "./footer"
import FloatingCartButton from "./floatingCartButton"
import OrderMenu from "./orderMenu/orderMenu"
import ConfirmOrder from "./orderMenu/confirmOrder"
import TermsConditions from "./termsConditions"
import "./layout.css"

const Layout = ({ children }) => {
  const [isConfirmModalOpen, toggleConfirmModal] = React.useState(false)
  const [isDrawerOpened, toggleDrawer] = React.useState(false)
  const termsConditionIsOpen = useSelector(store => store.termsConditionIsOpen)
  const toggle = () => {
    toggleDrawer(!isDrawerOpened)
  }

  return (
    <StaticQuery
      query={graphql`
        query SiteTitleQuery {
          site {
            siteMetadata {
              title
            }
          }
        }
      `}
      render={data => (
        <Page>
          <Header siteTitle={data.site.siteMetadata.title} />
          <main>{children}</main>

          <FloatingCartButton toggleSidebar={toggle} />
          {isDrawerOpened && (
            <OrderMenu
              toggleView={toggle}
              toggleConfirmModal={toggleConfirmModal}
            />
          )}
          <ConfirmOrder
            isOpen={isConfirmModalOpen}
            toggleModal={toggleConfirmModal}
          />
          <footer>
            <Footer />
          </footer>

          {termsConditionIsOpen && (
            <TermsConditions isOpen={termsConditionIsOpen} />
          )}
        </Page>
      )}
    />
  )
}

Layout.propTypes = {
  children: PropTypes.node.isRequired,
}

export default Layout
