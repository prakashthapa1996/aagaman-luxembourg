import React from 'react'

import {galleryImages} from "../resources"

const Gallery = ({limit = 0}) => {
  limit = limit || galleryImages.length

  return (
    <div>
      <div className="col-md-10 mx-auto py-3">
        <div className="gallery-grid">
          {
            [...galleryImages].splice(0,limit).map((image) => <div className="gallery-grid-item" key={image}><img className="gallery-image" src={image} alt=""/></div>)
          }
        </div>
      </div>
    </div>
  )
}
export default Gallery