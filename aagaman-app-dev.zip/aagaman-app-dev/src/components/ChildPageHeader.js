import React from "react"

const ChildPageHeader = ({ title, className }) => {
  const sectionClassName = className
    ? `${className} child-page-header`
    : "child-page-header"

  return (
    <section className={sectionClassName}>
      <div className="container text-center">
        <h1 className="section-header text-white">{ title }</h1>
      </div>
    </section>
  )
}

export default ChildPageHeader
