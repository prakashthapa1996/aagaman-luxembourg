import React from "react"
import { Link } from "gatsby"
import aagamanLogo from "../images/aagaman-logo.png"

const Footer = () => {
  return (
    <div>
      <div>
        <img src={aagamanLogo} alt="Aagaman Logo" />
      </div>
      <div className="row col-md-10 mx-auto mt-2">
        <div className="col-lg-3 col-md-4">
          <u>
            <strong>Contact Us</strong>
          </u>
          <div>
            <div>
              <i className="fas fa-phone-alt contact"></i>
              <a href="tel:+352-691572434" className="bold">
                +352-691572434
              </a>
            </div>
            <div>
              <i className="fas fa-phone-alt contact"></i>
              <a href="tel:+352-24559701" className="bold">
                +352-24559701
              </a>
            </div>
            <div>
              <i className="fas fa-paper-plane contact"></i>
              <a href="mailto:contact@aagaman.lu" className="bold">
                contact@aagaman.lu
              </a>
            </div>
            <a href="https://www.facebook.com/aagamanlux/">
              <i className="fab fa-facebook social"></i>
            </a>
            <a href="https://www.instagram.com/resturant_aagaman/">
              <i className="fab fa-instagram social"></i>
            </a>
          </div>
        </div>

        <div className="col-lg-6 col-md-4 font-sm">
          <div>
            <p>
              A classy Nepali food restaurant located in Esch-sur-Alzette,
              Luxembourg where we serve tasty, healthy meals in a family
              environment.
            </p>
            <p>Also, remember us for parties, events and home delivery.</p>
          </div>
          <div className='my-4'>
            <u>
              <strong>Opening Hours</strong>
            </u>
            <table className='mx-auto mt-2'>
              <tbody>
                <tr className='mb-2'>
                  <td className='px-2'><b>Tuesday - Sunday</b></td>
                  <td className='px-2'>
                    <div>11:45 to 14:00 hrs</div>
                    <div>18:00 to 22:45 hrs</div>              
                  </td>
                </tr>
                <tr>
                  <td className='px-2'><b>Monday</b></td>
                  <td className='px-2'>Closed</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="col-lg-3 col-md-4">
          <ol style={{lineHeight: "2rem"}}>
            <li>
              <Link className="link-primary" to="/">
                Home
              </Link>
            </li>
            <li>
              <Link className="link-primary" to="/menu">
                Menu
              </Link>
            </li>
            <li>
              <Link className="link-primary" to="/gallery">
                Gallery
              </Link>
            </li>
            <li>
              <Link className="link-primary" to="/reserve-table">
                Reserve a Table
              </Link>
            </li>
            <li>
              <Link className="link-primary" to="/contact-us">
                Contact Us
              </Link>
            </li>
          </ol>
        </div>
      </div>
      <div className="footer-bottom">
        © {new Date().getFullYear()} Aagaman, Luxembourg
      </div>
    </div>
  )
}
export default Footer
