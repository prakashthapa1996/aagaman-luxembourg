import React from 'react';
import { useDispatch } from 'react-redux';
import { openTermsConditions } from '../store/actions/termsConditions';

export default ({categories, setFilter}) => {
  const dispatch = useDispatch()
  const openTermsModal = (e) => {
    e.preventDefault()
    dispatch(openTermsConditions())
  }

  return (
    <div className="menu-row col-md-12 sticky-t-0 px-1" style={{background: "white", zIndex: 4}}>
      <div className="px-1 py-2">
        <input id="searchInput" name="searchInput" className="form-control search-input"
            placeholder="Search Menu" onChange={(e) => setFilter(e.target.value)} />
      </div>
      <span className="px-1 py-2"> <a href="#" className="link-terms-conditions font-sm" onClick={openTermsModal}> Open Terms & Conditions </a></span>
      {/*<div className="px-1 py-2">
        <select id="categoryInput" name="categoryInput" className="form-control category-input">
          <option value=""  hidden default> Select a Category </option>
          {
            categories.map(({id, name}) => <option key={id} value={id}> {name} </option>)  
          }
        </select>
        </div>*/}

        
    </div>
  );
}