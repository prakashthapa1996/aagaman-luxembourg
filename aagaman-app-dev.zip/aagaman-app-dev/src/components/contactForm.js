import React from "react"
import {navigate} from 'gatsby'
import {sendMail} from '../api/mail'

const ContactForm = (props) => {
  const nameRef = React.createRef()
  const phoneRef = React.createRef()
  const emailRef = React.createRef()
  const messageRef = React.createRef()
   
  const submitForm = (e) => {
    e.preventDefault()
    let name = nameRef.current.value
    let phone = phoneRef.current.value
    let email = emailRef.current.value
    let message = messageRef.current.value

    const htmlMessage = () => {
      return `<h4>Message Details </h4>
      <div><strong>Name : </strong>${name}</div>
      <div><strong>Email : </strong>${email || '<i>Unavailable</i>'}</div>
      <div><strong>Phone : </strong>${phone || '<i>Unavailable</i>'}</div>
      <div><strong>Message : </strong>${message || '<i>Unavailable</i>'}</div>`
    }

    const body = {
      to: "contact@aagaman.lu",
      subject: `New Message in Aagaman`,
      html: htmlMessage()
    }
     
    sendMail(body).then(() => {
      nameRef.current.value = ''
      phoneRef.current.value = ''
      emailRef.current.value = ''
      messageRef.current.value = ''
      navigate('/')})
  }

  return (
    <div className="py-3 col-md-10 mx-auto contact-form">
      <form onSubmit={submitForm}>
        <div className="row">
          <div className="col-md-6">
            <div className="form-group">
              <input ref={nameRef} required autoComplete="off" type="name" name="name" className="form-control" placeholder="Your Name *"  />
            </div>
            <div className="form-group">
              <input ref={emailRef} autoComplete="off" type="email" name="email" className="form-control" placeholder="Your Email"  />
            </div>
            <div className="form-group">
              <input ref={phoneRef} autoComplete="off" type="tel" name="phone" className="form-control" placeholder="Your Phone Number"  />
            </div>
          </div>
          <div className="col-md-6">
            <div className="form-group">
              <textarea ref={messageRef} autoComplete="off" required name="message" className="form-control" placeholder="Your Message *"  style={{width:"100%", height:"150px"}}/>
            </div>
          </div>
          <div className="form-group">
            <button type="submit" name="btnSubmit" className="btnContact btn btn-primary mx-3">Send Message</button>
          </div>
        </div>
      </form>
    </div>
  )
}

export default ContactForm