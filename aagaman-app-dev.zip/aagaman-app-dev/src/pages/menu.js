import React from "react"
import {useSelector, useDispatch} from 'react-redux'
import Layout from "../components/layout"
import SEO from "../components/seo"
import Searchbox from "../components/searchbox"
import MenuItem from "../components/menuItem"
import CategoryList from "../components/categoryList"
import ChildPageHeader from "../components/ChildPageHeader"
import { openTermsConditions } from "../store/actions/termsConditions";

const MenuPage = () => {
  
  const menu = useSelector(store => store.menu)
  const categories = useSelector(store => store.categories)
  const cartMenu = useSelector(store => store.cartMenu)
  const [filter, setFilter] = React.useState("")
  const filterMenu = (param) => {
    setFilter(param)
  }

  const filterMenuItems = (menuItems, filter) => menuItems.filter(item => item.name.toLowerCase().includes(filter.toLowerCase()))

  const getMenuByCategoryId = (categoryId) => {
    return menu.filter(menuItem => menuItem.categoryId === categoryId)
  }

  const isAddedToCart = (itemId) => !!cartMenu.find(menuItem => menuItem.id === itemId)

  const dispatch = useDispatch()
  React.useEffect(() => {
    dispatch(openTermsConditions())
  }, [])

  return (
    <Layout>
      <SEO title="Menu" />

      <ChildPageHeader className='menu-header' title='Our Menu'/>
      <div className="nowrap col-lg-10 mx-auto my-2">
        <section className="menu-categories">
          <CategoryList categories={categories} />
        </section>
  
        <section className="menu-food-list">
          <Searchbox categories={categories} setFilter={ filterMenu } />
          <ul>
            {
              categories.map(category => (
                <li id={`menu-${category.id}`} key={category.id}>
                  <div>
                    <h6 className="menu-category sticky-t-4"> { category.name } </h6>
                    <ul className="menu-content">
                      {
                        filterMenuItems( getMenuByCategoryId(category.id), filter).length < 1 ?
                        
                        <p><i>No content here</i></p> :

                        filterMenuItems(getMenuByCategoryId(category.id), filter).map(item => (
                          <li className="menu-item" key={item.id}>
                            <MenuItem data={item} isAddedToCart={isAddedToCart(item.id)}/>
                          </li>
                        ))
                      }
                    </ul>
                  </div>
                </li>
              ))
            }
          </ul>
        </section>
      </div>
      
    </Layout>
  )
}

export default MenuPage
