import React from "react"

import Layout from "../components/layout"
import SEO from "../components/seo"
import GalleryComponent from '../components/gallery'
import ChildPageHeader from "../components/ChildPageHeader";

const Gallery = () => (
  <Layout>
    <SEO title="Gallery " />

    <ChildPageHeader className='gallery-header' title='Gallery'/>

    <section>
      <GalleryComponent limit={0}/>
    </section>
  </Layout>
)

export default Gallery
