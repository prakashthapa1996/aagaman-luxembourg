import React from "react"
import { Link } from "gatsby"

import Layout from "../components/layout"
import SEO from "../components/seo"
import ContactForm from "../components/contactForm"
import Gallery from '../components/gallery'

const IndexPage = () => {
  return (
  <Layout>
    <SEO title="Home" />
    <section className="masthead masthead-page home"  >
      <div className="container" style={{minHeight: '20rem'}}>
          <div className="col-md-8 pt-5 h5">
            <h1 className="display-4 page-header">Welcome to Restaurant Aagaman </h1>
            <p className="page-subtitle">Nepalese, Indian and Himalayan cuisine</p>
          </div>
      </div>
    </section>

    <section>
      <div className="text-center">
        <div className="pt-5">
          <h1 className="page-header section-header">Our Services</h1>
          <p className="col-md-8 mx-auto py-3">We deliver the best quality food at the best price. Right at your doorstep. Also remember us for for any parties, celebrations and home delivery.</p>
        </div>
      </div>
    </section>

    <section>
      <div className="pt-5 text-center gallery-home">
        <h1 className="section-header">Gallery</h1>
        <Gallery limit={6} />
        <Link to="/gallery"><button className="btn btn-primary my-2">More</button></Link>
      </div>
    </section>

    <section>
      <h3 className="pt-5 section-header text-center">Drop Us a Message</h3>
      <ContactForm />
    </section>
  </Layout>
)}

export default IndexPage
