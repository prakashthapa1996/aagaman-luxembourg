import React, { useEffect } from "react"
import Layout from "../components/layout"
import SEO from "../components/seo"
import ChildPageHeader from "../components/ChildPageHeader"

const ReserveTable = () => {
  // const nameRef = React.createRef()
  // const phoneRef = React.createRef()
  // const emailRef = React.createRef()
  // const dateRef = React.createRef()
  // const timeRef = React.createRef()
  // const guestCountRef = React.createRef()
  // const messageRef = React.createRef()

  // const submitForm = (e) => {
  //   e.preventDefault()
  //   let name = nameRef.current.value
  //   let phone = phoneRef.current.value
  //   let email = emailRef.current.value
  //   let date = dateRef.current.value
  //   let time = timeRef.current.value
  //   let guestCount = guestCountRef.current.value
  //   let message = messageRef.current.value

  //   const htmlMessage = () => {
  //     return `<h4>Table Reservation Details </h4>
  //     <div><strong>Name : </strong>${name}</div>
  //     <div><strong>Email : </strong>${email || '<i>Unavailable</i>'}</div>
  //     <div><strong>Phone : </strong>${phone}</div>
  //     <div><strong>Date : </strong>${date}</div>
  //     <div><strong>Time : </strong>${time}</div>
  //     <div><strong>No. of Guests : </strong>${guestCount}</div>
  //     <div><strong>Message : </strong>${message || '<i>Unavailable</i>'}</div>`
  //   }

  //   const body = {
  //     to: "contact@aagaman.lu",
  //     subject: 'Table Reservation',
  //     html: htmlMessage()
  //   }
     
  //   sendMail(body).then(() => {
  //     nameRef.current.value = ''
  //     phoneRef.current.value = ''
  //     emailRef.current.value = ''
  //     dateRef.current.value = ''
  //     timeRef.current.value = ''
  //     guestCountRef.current.value = ''
  //     messageRef.current.value = ''
  //     navigate('/')})
  // }

  useEffect(() => {
    const script = document.createElement('script')
    script.src = 'https://reservations.tablebooker.com/tbkr-widget-import.min.js';
    script.async = true;
    document.body.appendChild(script)
    return () => {
      document.body.removeChild(script)
    }
  }, [])
  return (
    <Layout>
      <SEO title="Reserve a Table" />

      <ChildPageHeader title="Reserve a Table" className='reserve-table-header' />

      <div className="container pt-3 col-md-10 contact-form">
        
        <tbkr-bm-widget restaurant-id="16847408" source="website" use-modal="0" lang="en" theme="light"></tbkr-bm-widget>
        {/* 
        <form onSubmit={submitForm}>
          <div className="row">
            <div className="col-md-6">
              <div className="form-group">
                <input required ref={nameRef} type="text" name="name" className="form-control" placeholder="Your Name *"  autoComplete="off" />
              </div>
              <div className="form-group">
                <input ref={emailRef} type="text" name="email" className="form-control" placeholder="Your Email"  autoComplete="off" />
              </div>
              <div className="form-group">
                <input required ref={phoneRef} type="tel" name="phone" className="form-control" placeholder="Your Phone Number *"  autoComplete="off" />
              </div>
              <div className="form-group">
                <input required ref={guestCountRef} type="number" name="guestCount" className="form-control" placeholder="Number of Guests expected *"  autoComplete="off" />
              </div>
            </div>
            <div className="col-md-6">
              <div className="form-group">
                <input required ref={dateRef} type="date" name="date" className="form-control" placeholder="Your Phone Number *"  autoComplete="off" />
              </div>
              <div className="form-group">
                <input required ref={timeRef} type="time" name="time" className="form-control" placeholder="Your Phone Number *"  autoComplete="off" />
              </div>
              <div className="form-group">
                <textarea ref={messageRef} name="message" className="form-control" placeholder="Additional Message" autoComplete="off" style={{width:"100%", height:"96px"}}></textarea>
              </div>
            </div>
            <div className="form-group">
              <button type="submit" name="btnSubmit" className="btnContact btn btn-primary mx-3">Send Message</button>
            </div>
          </div>
        </form>
        */}
      </div>
    </Layout>
  )
}

export default ReserveTable
