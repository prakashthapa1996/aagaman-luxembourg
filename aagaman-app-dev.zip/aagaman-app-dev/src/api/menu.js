export const requestMenu = () => {
  const menuUrl = "https://spreadsheets.google.com/feeds/cells/1ZNGzOjdEEQRAQ3_tvYP5ZhJpQypbyaomsqUeIYuu5SU/1/public/full?alt=json"

  const filter = jsonData => {
    const entry = jsonData.feed.entry
    const menuObject = []

    for (let i = 6; i < entry.length; i += 6) {
      const id = entry[i].content["$t"]
      const name = entry[i + 1].content["$t"]
      const price = entry[i + 2].content["$t"]
      const categoryId = entry[i + 3].content["$t"]
      const descriptionRaw = entry[i + 4].content["$t"]
      const metaRaw = entry[i + 5].content["$t"]

      const description =
        descriptionRaw &&
        (descriptionRaw === "~" ? undefined : descriptionRaw.split("||"))
      const meta =
        metaRaw && (metaRaw === "~" ? undefined : metaRaw.split("||"))

      menuObject.push({
        id,
        name,
        price,
        categoryId,
        description,
        meta,
      })
    }
    return menuObject
  }

  return fetch(menuUrl)
    .then(response => response.json())
    .then(data => filter(data))
}
