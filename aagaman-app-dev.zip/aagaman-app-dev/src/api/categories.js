export const requestCategories = () => {
  const categoriesUrl =
    "https://spreadsheets.google.com/feeds/cells/1ZNGzOjdEEQRAQ3_tvYP5ZhJpQypbyaomsqUeIYuu5SU/2/public/full?alt=json"

  const filter = jsonData => {
    const entry = jsonData.feed.entry
    const categoriesObject = []

    for (let i = 2; i < entry.length; i += 2) {
      const id = entry[i].content["$t"]
      const name = entry[i + 1].content["$t"]

      categoriesObject.push({ id, name })
    }
    return categoriesObject
  }

  return fetch(categoriesUrl)
    .then(response => response.json())
    .then(data => filter(data))
}