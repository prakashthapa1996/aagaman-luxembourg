//const proxyUrl = 'https://cors-anywhere.herokuapp.com/'
const remoteUrl = 'https://node-express-email.herokuapp.com/email'
export function sendMail (body){
  return fetch( remoteUrl , {
    method: 'post',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  })
  .then(response => {
    console.log(response)
  })
}
