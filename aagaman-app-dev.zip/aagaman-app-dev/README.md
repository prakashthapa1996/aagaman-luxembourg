# Prerequisites
>Make sure you have `yarn` and `firebase-tools` installed globally.

>To run the project in local environment
```
yarn install
yarn run develop
```
>One-time-login to firebase project using `firebase-tools`
```
firebase login
```
>and input the necessary firebase login details.

# Build the project
```
yarn run build
```
>Check whether the changes are reflected properly in firebase dev environment
```
firebase serve
```
>and see the changes in http://localhost:5000.

>Once the changes are done, push the code to firebase server, which automatically reflects the code to aagaman.lu
```
firebase deploy
```
